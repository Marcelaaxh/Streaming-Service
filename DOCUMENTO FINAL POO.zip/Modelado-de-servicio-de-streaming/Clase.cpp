#include "Clase.h"

Clase::Clase(vector<Video*> v){
  for(int i=0; i<v.size();i++){
    vecVid.push_back(v[i]);
  }
}