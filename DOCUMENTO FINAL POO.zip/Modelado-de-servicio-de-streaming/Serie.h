#ifndef SOBRE_H
#define SOBRE_H
#pragma once

#include "Episode.h"

class Serie: public Episode{
private:
    int n_episodios;
    vector<Episode> misEp;
public:
    Serie(){};
    Serie(int, string, char,vector<Episode>); // No usar apuntador y generar un vector de objeto sin apuntadores.
    int getNEpisodes();
    void setNEpisodes(int);
    void getInfo();
    void calC();
};

#endif