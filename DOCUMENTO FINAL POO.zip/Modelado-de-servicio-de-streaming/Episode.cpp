#include "Episode.h"

Episode::Episode(){
  
}

Episode::Episode(int n, int s, string t, double d) {
  num=n;
  season=s;
  setNombre(t);
  setDuracion(d);
}

int Episode::getSeason() {
    return season;
}

void Episode::setSeason(int season) {
    this->season = season;
}

void Episode::getInfo(){
  cout<<num<<": "<<getNombre()<<endl;
  cout<<"Duración: "<<getDuracion()<<" minutos"<<endl;
  cout<<"Calificación Promedio: "<<getCalificacionPromedio()<<endl;
  
}