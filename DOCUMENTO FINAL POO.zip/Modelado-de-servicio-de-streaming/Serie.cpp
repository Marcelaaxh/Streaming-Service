#include "Serie.h"

Serie::Serie(int videoID, string videoNombre, char videoGenero,vector<Episode> eps){
  setID(videoID);
  setNombre(videoNombre);
  setGenero(videoGenero);
  n_episodios=eps.size();
  for(int i=0; i<eps.size(); i++){
    misEp.push_back(eps[i]);
  }
  setTipo('S');
}

int Serie::getNEpisodes() {
    return n_episodios;
}

void Serie::setNEpisodes(int numEpisodios) {
    n_episodios = numEpisodios;
}

void Serie::getInfo(){
  cout<<"ID: "<<getID()<<endl;
  cout<<"Nombre: "<<getNombre()<<endl;
  if(getGenero()=='D'){
    cout<<"Género: Drama"<<endl;
  }
  else if(getGenero()=='B'){
    cout<<"Género: Biografía"<<endl;
  }
  else if(getGenero()=='C'){
    cout<<"Género: Comedia"<<endl;
  }
  else if(getGenero()=='O'){
    cout<<"Género: Documental"<<endl;;
  }
  cout<<"Calificación promedio: "<<getCalificacionPromedio()<<endl;
  int s=0;
  for(int i=0;i<misEp.size();i++){
    if(misEp[i].getSeason()>s){
      s=misEp[i].getSeason();
    }
  }
  for(int i=1;i<=s;i++){
    cout<<"Temporada "<<i<<": "<<endl;
    for(int j=0;i<misEp.size();j++){
      if(misEp[j].getSeason()==i){
        misEp[j].getInfo();
      }
    }
  }
}

void Serie::calC(){
  float c=0;
  for(int i=0;i<misEp.size();i++){
    c=c+misEp[i].getCalificacionPromedio();
  }
  c=c/misEp.size();
  setCalificacionPromedio(c);
}