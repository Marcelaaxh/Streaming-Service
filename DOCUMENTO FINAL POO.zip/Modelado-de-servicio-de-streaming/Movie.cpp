#include "Movie.h"

Movie::Movie(int id, string nombre, double duracion, char genero){
  setID(id);
  setNombre(nombre);
  setDuracion(duracion);
  setGenero(genero);
  setTipo('V');
}

void Movie::getInfo(){
  cout<<"ID: "<<getID()<<endl;
  cout<<"Título: "<<getNombre()<<endl;
  if(getGenero()=='D'){
    cout<<"Género: Drama"<<endl;
  }
  else if(getGenero()=='B'){
    cout<<"Género: Biografía"<<endl;
  }
  else if(getGenero()=='C'){
    cout<<"Género: Comedia"<<endl;
  }
  else if(getGenero()=='O'){
    cout<<"Género: Documental"<<endl;;
  }
  cout<<"Duración: "<<getDuracion()<<" minutos"<<endl;
  cout<<"Calificación promedio: "<<getCalificacionPromedio()<<endl;
}



//int Movie::getYear() {
    //return year;
//}

//void Movie::setYear(int year) {
    //this->year = year;
//}
