#include <iostream>
#include "Serie.h"
#include "Movie.h"
#include "Clase.h"
#include <fstream>
using namespace std;

int main() {
  vector <Episode> epS;
  Episode ep1s(1,1,"Celebration",61);
  ep1s.agregarCalificacion(4.5);
  ep1s.agregarCalificacion(3.2);
  ep1s.agregarCalificacion(4.1);
  epS.push_back(ep1s);
  Episode ep2s(2,1,"Lifeboats",58);
  ep2s.agregarCalificacion(5);
  ep2s.agregarCalificacion(3.7);
  ep2s.agregarCalificacion(4.3);
  ep2s.agregarCalificacion(4);
  ep2s.agregarCalificacion(2.5);
  epS.push_back(ep2s);
  Episode ep3s(3,1,"Which side are you on?",58); 
  ep3s.agregarCalificacion(2);
  ep3s.agregarCalificacion(3.8);
  ep3s.agregarCalificacion(4.2);
  ep3s.agregarCalificacion(4.7);
  epS.push_back(ep3s);
  //Crear episodios para Succession
  vector <Episode> epNP;
  Episode ep1NP(1,1,"Warped Windows",27); //same
  ep1NP.agregarCalificacion(3.8);
  ep1NP.agregarCalificacion(4.1);
  ep1NP.agregarCalificacion(4.6);
  epS.push_back(ep1NP);
  Episode ep2NP(2,1,"Did It To Mysel",30); //same
  ep2NP.agregarCalificacion(3.3);
  ep2NP.agregarCalificacion(4.8);
  ep2NP.agregarCalificacion(4.9);
  ep2NP.agregarCalificacion(3.7);
  ep2NP.agregarCalificacion(4);
  ep2NP.agregarCalificacion(5);
  epS.push_back(ep2NP);
  Episode ep3NP(3,1,"Angeles",32); //same
  ep3NP.agregarCalificacion(4.7);
  ep3NP.agregarCalificacion(4.9);
  ep3NP.agregarCalificacion(4);
  epS.push_back(ep3NP);
  Episode ep4NP(1,2,"Love will tear us apart",26); //same
  ep4NP.agregarCalificacion(4.4);
  ep4NP.agregarCalificacion(3.9);
  ep4NP.agregarCalificacion(2);
  ep4NP.agregarCalificacion(1);
  epS.push_back(ep4NP);
  Episode ep5NP(2,2,"Everything I Am Is Yours",31); //same
  ep5NP.agregarCalificacion(2.1);
  ep5NP.agregarCalificacion(1.7);
  epS.push_back(ep5NP);
  //Crear episodios para Normal People
  vector <Episode> epCwF;
  Episode ep1CwF(1,1,"Episode 1",32);//same
  ep1CwF.agregarCalificacion(2.1);
  ep1CwF.agregarCalificacion(3.7);
  ep1CwF.agregarCalificacion(4.1);
  ep1CwF.agregarCalificacion(4.7);
  epCwF.push_back(ep1CwF);
  Episode ep2CwF(1,2,"Episode 2",34);//same
  ep2CwF.agregarCalificacion(4);
  ep2CwF.agregarCalificacion(5);
  ep2CwF.agregarCalificacion(4.9);
  epCwF.push_back(ep2CwF);
  Episode ep3CwF(1,3,"Episode 3",27);//same
  ep3CwF.agregarCalificacion(5);
  ep3CwF.agregarCalificacion(5);
  ep3CwF.agregarCalificacion(3.9);
  ep3CwF.agregarCalificacion(4.2);
  ep3CwF.agregarCalificacion(5);
  epCwF.push_back(ep3CwF);
  Episode ep4CwF(2,1,"Episode 4",32);//same
  ep4CwF.agregarCalificacion(2.9);
  ep4CwF.agregarCalificacion(3.2);
  ep4CwF.agregarCalificacion(4);
  epCwF.push_back(ep4CwF);
  Episode ep5CwF(2,2,"Episode 5",34);//same
  ep5CwF.agregarCalificacion(2.2);
  ep5CwF.agregarCalificacion(3);
  epCwF.push_back(ep5CwF);
  Episode ep6CwF(2,3,"Episode 6",28);//same
  ep6CwF.agregarCalificacion(1.2);
  epCwF.push_back(ep6CwF);
  //Crear episodios para Conversation with friends
  vector <Episode> epGGs;
  Episode ep1GGs(1,1,"Haunted leg",41); //same
  ep1GGs.agregarCalificacion(4.2);
  ep1GGs.agregarCalificacion(5);
  ep1GGs.agregarCalificacion(3.9);
  ep1GGs.agregarCalificacion(4);
  epGGs.push_back(ep1GGs);
  Episode ep2GGs(2,1,"Application anxiety",44); //same
  ep2GGs.agregarCalificacion(5);
  ep2GGs.agregarCalificacion(2.9);
  ep2GGs.agregarCalificacion(4.4);
  epGGs.push_back(ep2GGs);
  Episode ep3GGs(3,1,"They shoot gilmores, don´t they?",40); //same
  ep3GGs.agregarCalificacion(4.7);
  ep3GGs.agregarCalificacion(4.9);
  ep3GGs.agregarCalificacion(3.4);
  epGGs.push_back(ep3GGs);
  Episode ep4GGs(4,1,"Let the games begin",43); //same
  ep4GGs.agregarCalificacion(4.7);
  ep4GGs.agregarCalificacion(3.9);
  ep4GGs.agregarCalificacion(4.4);
  ep4GGs.agregarCalificacion(1.7);
  epGGs.push_back(ep4GGs);
  //Crear episodios para glimore girls
  vector <Episode> epGG;
  Episode epGG1(1,1,"Belles de jour",40);
  epGG1.agregarCalificacion(5);
  epGG1.agregarCalificacion(0.7);
  epGG.push_back(epGG1);
  Episode epGG2(2,1,"Double identity",41);
  epGG2.agregarCalificacion(5);
  epGG2.agregarCalificacion(4.7);
  epGG2.agregarCalificacion(4.9);
  epGG.push_back(epGG2);
  Episode epGG3(3,1,"The undergraduates",41);
  epGG3.agregarCalificacion(4.7);
  epGG3.agregarCalificacion(4.7);
  epGG3.agregarCalificacion(4.9);
  epGG.push_back(epGG3);
  Episode epGG4(1,2,"Touch of Eva",41);
  epGG4.agregarCalificacion(3.7);
  epGG4.agregarCalificacion(4.7);
  epGG.push_back(epGG4);
  Episode epGG5(2,2,"Goodbye, Columbia",41);
  epGG5.agregarCalificacion(2.7);
  epGG5.agregarCalificacion(3.7);
  epGG5.agregarCalificacion(2.7);
  epGG5.agregarCalificacion(4.1);
  epGG.push_back(epGG5);
  Episode epGG6(3,2,"Easy J",41);
  epGG6.agregarCalificacion(4.7);
  epGG6.agregarCalificacion(4.7);
  epGG6.agregarCalificacion(3.1);
  epGG.push_back(epGG6);
  Episode epGG7(4,2,"War at the roses",41);
  epGG7.agregarCalificacion(2.7);
  epGG7.agregarCalificacion(1.1);
  epGG.push_back(epGG7);
  //Crear episodios para gossip girl
  
  vector<Video*> misVideos;
  Movie* v1=new Movie(111,"Aftersun",101,'D');
  v1->agregarCalificacion(5);
  v1->agregarCalificacion(4.9);
  v1->agregarCalificacion(4.8);
  v1->agregarCalificacion(4.9);
  misVideos.push_back(v1);
  Movie* v2=new Movie(222,"Little Woman",135,'D');
  v2->agregarCalificacion(3.9);
  v2->agregarCalificacion(4.7);
  v2->agregarCalificacion(4.2);
  misVideos.push_back(v2);
  Movie* v3=new Movie(333,"Babylon",189,'C');
  v3->agregarCalificacion(4.1);
  v3->agregarCalificacion(2.7);
  misVideos.push_back(v3);
  Movie* v4=new Movie(444,"The Social Network",120,'B');
  v4->agregarCalificacion(3.1);
  v4->agregarCalificacion(4.7);
  v4->agregarCalificacion(1);
  v4->agregarCalificacion(2.1);
  misVideos.push_back(v4);
  Movie* v5=new Movie(555,"Miss America",86,'O');
  v5->agregarCalificacion(4.9);
  v5->agregarCalificacion(5);
  v5->agregarCalificacion(5);
  misVideos.push_back(v5);
  Serie* v6=new Serie(666,"Succession",'D',epS);
  v6->calC();
  misVideos.push_back(v6);
  Serie* v7=new Serie(777,"Normal People",'D',epNP);
  v7->calC();
  misVideos.push_back(v7);
  Serie* v8=new Serie(888,"Conversation With Friends",'D',epCwF);
  v8->calC();
  misVideos.push_back(v8);
  Serie* v9=new Serie(999,"Gilmore Girls",'C',epGGs);
  v9->calC();
  misVideos.push_back(v9);
  Serie* v10=new Serie(101,"Gossip Girl",'D',epGG);
  v10->calC();
  misVideos.push_back(v10);

  Clase c(misVideos);
  
  int continuar;
  int op;
  cout<<"Presione 1 para inicia el programa"<<endl;
  cin>>continuar;
  while(continuar==1){
    cout<<"Elija una opción: "<<endl;
    cout<<"1. Mostrar los videos en general con una cierta calificación o de un cierto género"<<endl;
    cout<<"2. Mostrar los episodios de una determinada serie con una calificacion determinada"<<endl;
    cout<<"3. Mostrar las películas con cierta calificacion"<<endl;
    cout<<"4. Calificar un video"<<endl;
    cin>>op;
    while(op==1||op==2||op==3||op==4){
      if(op==1){
        int fil;
        cout<<"Filtrar por:"<<endl;
        cout<<"1. Calificación"<<endl;
        cout<<"2. Género"<<endl;
        cin>>fil;
        if(fil==1||fil==2){
          if(fil==1){
            float cb;
            cout<<"¿Qué calificación buscas? (1-5)"<<endl;
            cin>>cb;
            for(int i=0; i<c.vecVid.size();i++){
              c.vecVid[i]->filtercalifs(cb);
            }
          }
          else if(fil==2){
            char gen;
            cout<<"¿Qué género buscas?"<<endl;
            cout<<"D (drama), C (comedia), O (Documental), B (Biografía)"<<endl;
            cin>>gen;
            for(int i=0; i<c.vecVid.size();i++){
              c.vecVid[i]->filtergenero(gen);
            }
          }
          else{
            cout<<"Entrada inválida"<<endl;
          }
        }
      }
      else if(op==2){
        //here
        vector <Video*> misM;
        for(int i=0; i<c.vecVid.size();i++){
          if(c.vecVid[i]->getTipo()=='S'){
            misM.push_back(c.vecVid[i]);
          }
        }
        float cal;
        cout<<"¿Qué calificación quiere buscar?"<<endl;
        cin>>cal;
        for(int i=0; i<misM.size();i++){
          misM[i]->filtercalifs(cal);
        }
      }
      else if(op==3){
        vector <Video*> misM;
        for(int i=0; i<c.vecVid.size();i++){
          if(c.vecVid[i]->getTipo()=='M'){
            misM.push_back(c.vecVid[i]);
          }
        }
        float cal;
        cout<<"¿Qué calificación quiere buscar?"<<endl;
        cin>>cal;
        for(int i=0; i<misM.size();i++){
          misM[i]->filtercalifs(cal);
        }
      }
      else if(op==4){
        int id;
        cout<<"Ingrese el ID del título que desea calificar"<<endl;
        cin>>id;
        float cal;
        int ub;
        for(int i=0;i<c.vecVid.size();i++){
          if(c.vecVid[i]->getID()==id){
            cout<<"Ingrese la calificación del 1 al 5: "<<endl;
            cin>>cal;
            c.vecVid[i]->agregarCalificacion(cal);
            }
          }
        cout<<"La calificación ha sido agregada correctamente"<<endl;
      }
    cout<<"Para volver al menú presione 1, para salir ingrese cualquier otro número"<<endl;
    cin>>continuar;
    op=5;
  }
  }
}