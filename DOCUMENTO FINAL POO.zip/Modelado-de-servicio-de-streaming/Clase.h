#include "Serie.h"
#include "Movie.h"
#include <iostream>
using namespace std;

class Clase{
  public:
  vector<Video*> vecVid;
  Clase(vector<Video*> v);
};