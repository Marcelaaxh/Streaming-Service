#include <iostream>
using namespace std;
#include <vector>
#pragma once

class Video{

  private:
    int id;
    string nombre;
    double duracion;
    char genero;
    double calificacion_promedio;
    vector <float> califs;
    char tipo;

  public:
    Video();
    Video(int, string, double, char);
    int getID();
    void setID(int);
    string getNombre();
    void setNombre(string);
    double getDuracion();
    void setDuracion(double);
    char getGenero();
    void setGenero(char);
    double getCalificacionPromedio();
    double calcularCalificacionPromedio();
    void agregarCalificacion(float);
    void setCalificacionPromedio(float);
    void filtercalifs(float);
    void filtergenero(char);
    void setTipo(char);
    char getTipo();
    virtual void getInfo()=0;
    
};