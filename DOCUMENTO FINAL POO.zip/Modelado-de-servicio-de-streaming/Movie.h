#ifndef MOVIE_H
#define MOVIE_H
#pragma once

#include "Video.h"

class Movie : public Video {
private:
    //7int year;

public:
    Movie(){};
    Movie(int, string, double, char);
    void getInfo();
    //int getYear();
    //void setYear(int);
};

#endif
