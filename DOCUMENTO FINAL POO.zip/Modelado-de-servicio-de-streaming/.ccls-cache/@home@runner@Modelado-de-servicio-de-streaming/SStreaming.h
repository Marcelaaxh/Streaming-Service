#include <iostream>
using namespace std;

class SStreaming{
  public:
  void virtual filtercalifs()=0;
};