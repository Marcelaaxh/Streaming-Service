#include "Movie.h"
#include "Serie.h"
using namespace std;

class Streaming:public Serie, public Movie{
  public:
    void interfazU(vector <Video*>);
};