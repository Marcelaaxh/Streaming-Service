#include "Streaming.h"
using namespace std;

void Streaming::interfazU(vector <Video*> lvs){
  bool continuar=true;
  int op;
  while(continuar==true){
    cout<<"Elija una opción: "<<endl;
    cout<<"1. Cargar archivo de datos"<<endl;
    cout<<"2. Mostrar los videos en general con una cierta calificación o de un cierto género"<<endl;
    cout<<"3. Mostrar los episodios de una determinada serie con una calificacion determinada"<<endl;
    cout<<"4. Mostrar las películas con cierta calificacion"<<endl;
    cout<<"5. Calificar un video"<<endl;
    cin>>op;
    while(op==1||op==2||op==3||op==4||op==5){
      if(op==1){
        //here
      }
      else if(op==2){
        int fil;
        cout<<"Filtrar por:"<<endl;
        cout<<"1. Calificación"<<endl;
        cout<<"2. Género"<<endl;
        cin>>fil;
        while(fil==1||fil==2){
          if(fil==1){
            filtercalifs(lvs);
          }
          else if(fil==2){
            filtergenero(lvs);
          }
        }
        cout<<"Entrada inválida"<<endl;
      }
      else if(op==3){
        //here
      }
      else if(op==4){
        vector <Video*> misM;
        for(int i=0; i=lvs.size();i++){
          if(lvs[i]->getTipo()=='M'){
            misM.push_back(lvs[i]);
          }
        }
        filcalf(misM);
      }
      else if(op==5){
        agergarCalificacion(lvs);
      }
    }
    cout<<"Entrada inválida"<<endl;
  }
}