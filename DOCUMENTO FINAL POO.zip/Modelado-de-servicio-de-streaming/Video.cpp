#include "Video.h"

Video::Video(){
  
}

Video::Video(int id_, string n, double d, char g){
  id=id_;
  nombre=n;
  duracion=d;
  genero=g;
}

int Video::getID(){
  return id;
}

void Video::setID(int i_d){
  id=i_d;
}

string Video::getNombre(){
  return nombre;
}

void Video::setNombre(string n){
  nombre=n;
}

double Video::getDuracion(){
  return duracion;
}

void Video::setDuracion(double d){
  duracion=d;
}

char Video::getGenero(){
  return genero;
}

void Video::setGenero(char g){
  genero=g;
}

double Video::getCalificacionPromedio(){
  return calificacion_promedio;
}


double Video::calcularCalificacionPromedio(){
  int s=califs.size();

  float cs=0;
  for(int i=0;i<=s;i++){
    cs=cs+califs[i];
  }
  float cp=cs/s;
  calificacion_promedio=cp;
  return cp;
}

void Video::agregarCalificacion(float ac){
  califs.push_back(ac);
  calcularCalificacionPromedio();
}

void Video::filtercalifs(float c){
  if(getCalificacionPromedio()==c){
    getInfo();
  }
}

void Video::filtergenero(char g){
  if(getGenero()==g){
    getInfo();
  }
}

void Video::setTipo(char t){
  tipo=t;
}

char Video::getTipo(){
  return tipo;
}

void Video::setCalificacionPromedio(float cp){
  calificacion_promedio=cp;
}