//#ifndef EPISODE_H
//#define EPISODE_H
#pragma once

#include "Video.h"

class Episode : public Video {
private:
    int season;
    int num;
    //double rating;

public:
    Episode();
    Episode(int n, int s, string t, double d);
    int getSeason();
    void setSeason(int season);
    void getInfo();
    //double getRating();
    //void setRating(double rating);
};

//#endif
